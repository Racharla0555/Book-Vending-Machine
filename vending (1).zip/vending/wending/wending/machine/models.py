from django.db import models

# Create your models here.
class book(models.Model):
    name=models.CharField(max_length=50)
    author=models.CharField(max_length=50)
    price=models.FloatField()
    def __str__(self):
        return self.name
class booking(models.Model):
    name=models.CharField(max_length=50)
    hall=models.CharField(max_length=10)
    email=models.EmailField()
    book_name=models.CharField(max_length=50)
    book_author=models.CharField(max_length=50)
    book_price=models.FloatField()
    def __str__(self):
        return self.name
