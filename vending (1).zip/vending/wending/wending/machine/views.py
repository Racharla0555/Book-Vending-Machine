from django.shortcuts import render,redirect
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth import login,authenticate
# Create your views here.
from .models import *
def home(request):
    b=book.objects.all()
    return render(request,'home.html',{'book':b})
def signin(r):
    if r.method=='POST':
        username=r.POST['username']
        password=r.POST['password']
        user=authenticate(username=username,password=password)
        if user is not None:
            login(r,user)
            return redirect('/view')
    return render(r,"login.html")
def ok(request,id):
    b=book.objects.get(id=id)
    a=0
    k=0
    if request.method=='POST':
        name=request.POST['name']
        hall=request.POST['hall']
        email=request.POST['email']
        k=booking(name=name,email=email,hall=hall,book_name=b.name,book_author=b.author,book_price=b.price)
        k.save()
        a=1
    return render(request,'student.html',{'book':b,'a':a,'k':k})
@user_passes_test(lambda u:u.is_superuser)
def view(request):
    b=booking.objects.all()
    return render(request,'view.html',{'book':b})